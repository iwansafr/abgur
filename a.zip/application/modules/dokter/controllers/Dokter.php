<?php defined('BASEPATH') OR exit('No direct script access allowed');

Class Dokter extends CI_Controller
{
	public function index()
	{
		echo 'test';
	}
}